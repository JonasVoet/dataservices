import React from 'react';
import Cover from '../Cover/Cover';
import Main from '../Main-content/Main';

 const Home = () => {
    return (
        <div className="wrapper">
            
            <Cover />

            <main>

                <Main />
        
            </main>


            
        </div>
    )
}

export default Home;
